import React from 'react';

export const Session = (token) => {
    localStorage.setItem('token',token);
};

export const getSession =() =>
{
   return localStorage.getItem('token');
}

export const isLoged = () => {
    const token = localStorage.getItem('token');
    if(token)
        return true;
    else 
        return false;
};

export const CerrarSession = () =>
{
    localStorage.removeItem('token');
}
import {React, useState} from 'react';
import { Libros } from '../Hooks/ConexionSW';
import swal from 'sweetalert';

const mensaje = (texto) => swal
    (
        {
            tittle: "Error",
            text: texto,
            icon: "error",
            button: "Aceptar",
            timer: 2000
        }
    );

const LibrosView = () => {
    
    const [info, setInfo] = useState(undefined);
    const [llamada, setLlamada] = useState(false);
    const data = Libros().then((datos) =>
    {
        if(!llamada)
        {
            setInfo(datos);
            setLlamada(true);
        }
        
        
    }, (error) =>
    {
        mensaje(error.message);
    }); 

    return (
        <div className='container'>
            <div className='row'>
                <div className='card mx-auto col-4 text-center'>
                    <div className='card-tittle alert alert-info mb-2'>Libros</div>
                </div>

                <table className='table'>
                    <thead>
                        <tr>
                            <th>Numero</th><th>Autor</th><th>Titulo</th><th>Descripción</th><th>Editorial</th><th>Año</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            (info && info.lista && info.lista.map((element, key) =>
                            {
                                return( 
                                    <tr key={key}>
                                        <td>{(key)+1}</td>
                                        <td>{element.autores}</td>
                                        <td>{element.titulo}</td>
                                        <td>{element.descripcion}</td>
                                        <td>{element.editorial}</td>
                                        <td>{element.anio}</td>
                                    </tr>
                                )
                                
                            }))
                        }
                    </tbody>
                </table>
            </div>
            
            
        </div>
    );
};

export default LibrosView;